import React,{useState}from'react';import'./styles.css';

function App(){
const[formData,setFormData]=useState({fullName:"",email:"",password:"",confirmPass:""});
const handleChange=e=>setFormData({...formData,[e.target.name]:e.target.value});
const handleRegister=e=>{e.preventDefault();console.log("Data:",formData);};

return(
<div className="relative min-h-screen flex items-center justify-center p-4 overflow-hidden">
<div className="fade-bg absolute inset-0" style={{backgroundImage:"url('https://uploads.onecompiler.io/44fxtmxfy/44mt3nkk6/ChatGPT%20Image.png')",backgroundSize:"cover",backgroundPosition:"center"}}></div>
<div className="absolute inset-0 bg-black/60"></div>

<div className="relative z-10 w-full flex justify-center">
<main className="w-full max-w-sm mt-10">
<h1 className="text-4xl font-black text-white text-center mb-8 italic tracking-tighter">
Uni<span className="txt-flow">Connect</span>
</h1>

<div className="neon-shield bg-white/5 backdrop-blur-xl rounded-[40px] p-8 relative pt-14">
<div className="absolute -top-12 left-1/2 transform -translate-x-1/2">
<img src="https://uploads.onecompiler.io/44fxtmxfy/44fxtnnnt/profile.jpeg" className="profile-img"/>
</div>

<h2 className="text-white text-center font-bold text-xl mb-6">Create Account</h2>

<form className="space-y-4" onSubmit={handleRegister}>
<input name="fullName" placeholder="Full Name" value={formData.fullName} onChange={handleChange} className="w-full bg-white/5 border rounded-xl px-4 py-3 text-white"/>
<input name="email" placeholder="Email" value={formData.email} onChange={handleChange} className="w-full bg-white/5 border rounded-xl px-4 py-3 text-white"/>

<div className="flex gap-2">
<input name="password" type="password" placeholder="Pass" value={formData.password} onChange={handleChange} className="w-1/2 bg-white/5 border rounded-xl px-4 py-3 text-white"/>
<input name="confirmPass" type="password" placeholder="Confirm" value={formData.confirmPass} onChange={handleChange} className="w-1/2 bg-white/5 border rounded-xl px-4 py-3 text-white"/>
</div>

<button className="w-full bg-cyan-500 text-white py-3 rounded-xl">Register</button>
</form>
</div>
</main>
</div>
</div>
);
}
export default App;
